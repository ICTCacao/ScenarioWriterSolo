ScenarioWriterSolo（Windows 版）0.5

ScenarioWriterWin_0.5.0_x64-setup.exe … インストーラ（推奨）
ScenarioWriterWin-0.5.0-x64-portable.exe … インストールせずに使う単体の exe
ScenarioWriterWin-manual.pdf … 使い方

最初に起動するとき SmartScreen が出たら「詳細情報」→「実行」。
作品ファイル .scwd は Mac 版 ScenarioWriterSolo（β5 以降）と共通です。
