ScenarioWriterSolo（Windows 版）β5

ScenarioWriterWin-beta5-setup.exe … インストーラ（推奨）
ScenarioWriterWin-beta5-portable.exe … インストールせずに使う単体の exe
ScenarioWriterWin-manual.pdf … 使い方

最初に起動するとき SmartScreen が出たら「詳細情報」→「実行」。
作品ファイル .scwd は Mac 版 ScenarioWriterSolo（β5 以降）と共通です。
