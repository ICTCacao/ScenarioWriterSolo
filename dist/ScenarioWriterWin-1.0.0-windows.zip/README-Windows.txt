ScenarioWriterSolo（Windows 版）1.0.0

ScenarioWriterWin-1.0.0-setup.exe … インストーラ（推奨）
ScenarioWriterWin-1.0.0-portable.exe … インストールせずに使う単体の exe
ScenarioWriterWin-manual.pdf … 使い方
sample.scwd … 見本の作品（架空の短い戯曲「夕暮れの谷」）。まずこれを開いて試せます

最初に起動するとき SmartScreen が出たら「詳細情報」→「実行」。
作品ファイル .scwd は Mac 版 ScenarioWriterSolo（β5 以降）と共通です。
β9 から入れ替えるときに「新しい版が入っています」と出たら、そのまま続けるか、先に β9 をアンインストールしてください。
